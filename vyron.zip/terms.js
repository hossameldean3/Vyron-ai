import Nav from '../components/Nav';
import Footer from '../components/Footer';

export default function Terms(){
  return (
    <>
      <Nav />
      <main className="container py-12">
        <h1>Terms of Service</h1>
        <p>Terms stub. Replace with legal copy before launch.</p>
      </main>
      <Footer />
    </>
  );
}
