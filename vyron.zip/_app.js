import '../styles/globals.css';
import '../lib/sentry';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
