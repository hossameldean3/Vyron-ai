Place your large files here (do not commit huge binaries to GitHub):
- demo-video.mp4 (or use Cloudflare Stream and point to HLS URL)
- demo-video.m3u8 & segments if hosting HLS
- demo-poster.jpg
- logo.png
